-- phpMyAdmin SQL Dump
-- version 2.11.6
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 22, 2023 at 12:51 PM
-- Server version: 5.0.51
-- PHP Version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `qltt`
--

-- --------------------------------------------------------

--
-- Table structure for table `comdetail`
--

CREATE TABLE `comdetail` (
  `ChapID` int(11) NOT NULL auto_increment,
  `ChapName` varchar(100) NOT NULL,
  `ChapPrice` float NOT NULL,
  `ChapImage` varchar(100) NOT NULL,
  `ChapDescription` varchar(500) default NULL,
  `ComID` int(11) NOT NULL,
  PRIMARY KEY  (`ChapID`),
  KEY `ComID` (`ComID`),
  KEY `ComID_2` (`ComID`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=26 ;

--
-- Dumping data for table `comdetail`
--

INSERT INTO `comdetail` (`ChapID`, `ChapName`, `ChapPrice`, `ChapImage`, `ChapDescription`, `ComID`) VALUES
(1, 'Conan - tập 1', 20000, 'conan1.jpg', 'Mở đầu câu truyện, cậu học sinh trung học 17 tuổi (trong truyện tranh là 16) Shinichi Kudo (Jimmy Kudo) bị biến thành cậu bé Conan Edogawa. Shinichi trong phần đầu của Thám tử lừng danh Conan được miêu tả là một thám tử học đường. Trong một lần đi chơi công viên "Miền Nhiệt đới" với cô bạn từ thuở nhỏ (cũng là bạn gái) Ran Mori (Rachel Moore), cậu bị dính vào vụ án một hành khách trên Chuyến tàu tốc hành trong công viên, Kishida (Kenneth), bị giết trong một vụ án cắt đầu rùng rợn', 1),
(2, 'Conan - tập 2', 20000, 'conan2.jpg', '', 1),
(3, 'Conan - tập 3', 21000, 'conan3.jpg', NULL, 1),
(4, 'Conan - tập 4', 21000, 'conan4.jpg', NULL, 1),
(5, 'Conan - tập 5', 21000, 'conan5.jpg', NULL, 1),
(6, 'Doraemon - Tập 1', 16000, 'doraemon1.jpg', NULL, 2),
(7, 'Doraemon - Tập 2', 17000, 'doraemon2.jpg', NULL, 2),
(8, 'Doraemon - Tập 3', 17000, 'doraemon3.jpg', NULL, 2),
(9, 'Doraemon - Tập 4', 17000, 'doraemon4.jpg', NULL, 2),
(10, 'Doraemon - Tập 5', 18000, 'doraemon5.jpg', NULL, 2),
(11, 'Naruto - Tập 1', 19000, 'naruto1.jpg', NULL, 3),
(12, 'Naruto - Tập 2', 19000, 'naruto2.jpg', NULL, 3),
(13, 'Naruto - Tập 3', 19000, 'naruto3.jpg', NULL, 3),
(14, 'Naruto - Tập 4', 19000, 'naruto4.jpg', NULL, 3),
(15, 'Naruto - Tập 5', 20000, 'naruto5.jpg', NULL, 3),
(16, 'One Piece -Tập 1', 23000, 'onepiece1.jpg', NULL, 4),
(17, 'One Piece -Tập 2', 23000, 'onepiece2.jpg', NULL, 4),
(18, 'One Piece -Tập 3', 23000, 'onepiece3.jpg', NULL, 4),
(19, 'One Piece -Tập 4', 24000, 'onepiece4.jpg', NULL, 4),
(20, 'One Piece -Tập 5', 24000, 'onepiece5.jpg', NULL, 4),
(21, 'Shin - Cậu bé bút chì tập 1', 25000, 'shin1.jpg', NULL, 5),
(22, 'Shin - Cậu bé bút chì tập 2', 25000, 'shin2.jpg', NULL, 5),
(23, 'Shin - Cậu bé bút chì tập 3', 25000, 'shin3.jpg', NULL, 5),
(24, 'Shin - Cậu bé bút chì tập 4', 25500, 'shin4.jpg', NULL, 5),
(25, 'Shin - Cậu bé bút chì tập 5', 25500, 'shin5.jpg', NULL, 5);

-- --------------------------------------------------------

--
-- Table structure for table `comic`
--

CREATE TABLE `comic` (
  `ComID` int(11) NOT NULL auto_increment,
  `ComName` varchar(100) NOT NULL,
  `TacGia` varchar(50) NOT NULL,
  `NXB` varchar(50) NOT NULL,
  PRIMARY KEY  (`ComID`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `comic`
--

INSERT INTO `comic` (`ComID`, `ComName`, `TacGia`, `NXB`) VALUES
(1, 'Conan Thám Tử Lừng Danh', 'Gosho Aoyama', 'Kim Đồng'),
(2, 'Doraemon', 'Fujiko Fujio', 'Kim Đồng'),
(3, 'Naruto', 'Kishimoto Masashi', 'Kim Đồng'),
(4, 'One Piece', 'Oda Eiichiro', 'Kim Đồng'),
(5, 'Shin - Cậu bé bút chì', 'Usui Yoshito', 'Kim Đồng');
